# Template Manager - Full Version

A fast, modern email template manager built with Wise Design System colors and Inter font. Uses browser localStorage — no account or server needed.

## Features

- ✅ Create, edit, delete templates
- ✅ Custom delete confirmation modal (modern, no browser default)
- ✅ Eye icon with hover preview (0.5s delay) + Expand popup
- ✅ Advanced search (keywords match in any order, searches title + content)
- ✅ Drag & drop to reorder templates
- ✅ Adjustable grid: 1, 2, 3, or 4 columns
- ✅ Sidebar with template list + click to scroll
- ✅ Copy with checkmark feedback
- ✅ Wise Design System colors & Inter font
- ✅ Responsive design
- ✅ localStorage persistence (data survives shutdowns)

## File Structure

```
template-manager/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── assets/
    └── icons/
```

## How to Host on GitHub Pages

1. Create a repo named `your-username.github.io`
2. Upload all files
3. Settings → Pages → select main branch → Save
4. Visit `https://your-username.github.io`

## How to Host on Netlify

1. Push files to a GitHub repo
2. Go to netlify.com → New Site → Connect to GitHub
3. Deploy — done!

## Local Testing

Open `index.html` directly in your browser. No server needed.
